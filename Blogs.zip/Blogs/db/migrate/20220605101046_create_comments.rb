class CreateComments < ActiveRecord::Migration[7.0]
  def change
    create_table :comments do |t|

      t.timestamps
      # belongs_to :user
      # belongs_to :blog
    end
  end
end
