class CreateBlogs < ActiveRecord::Migration[7.0]
  def change
    create_table :blogs do |t|

      t.timestamps
      # belongs_to :user
      # has_many :comments
    end
  end
end
