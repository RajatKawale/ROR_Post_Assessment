class BlogsController < ApplicationController
    def new
        
    end

    # def index 
    #     blog = Blog.new(user_id: session[:id], title: params[:title], body: params[:body])
    #     if blog.save
    #         #session[:id] = user.id
    #         #session[:name] = user.name
    #         flash[:notice] = "signed-up successful"
    #         redirect_to '/home'
    #         #render plain: "Successfully done"
    #     else
    #         flash[:registration_errors] = user.errors.full_messages
    #         redirect_to '/errors'
    #     end
    # end

    def create
        blog = Blog.new(user_id: session[:id], title: params[:title], body: params[:body])
        if blog.save
            #session[:id] = user.id
            #session[:name] = user.name
            flash[:notice] = "signed-up successful"
            redirect_to '/home'
            #render plain: "Successfully done"
        else
            flash[:registration_errors] = user.errors.full_messages
            redirect_to '/errors'
        end

    end

    def show
    end

    def delete
        Comment.delete_by(blog_id: params[:blog_id])
        if Blog.delete(params[:blog_id])
            redirect_to '/home'
        else
            flash[:registration_errors] = "Can't delete, please try again"
            redirect_to '/home'
        end
    end
end
